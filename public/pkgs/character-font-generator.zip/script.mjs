import XLSX from 'xlsx';
import fs from 'fs';
import { SVGIcons2SVGFontStream } from 'svgicons2svgfont';
import { createReadStream, createWriteStream } from 'node:fs';
import svg2ttf from 'svg2ttf';
import { Jimp } from 'Jimp';
import {exec} from 'child_process';
import util from 'util';
const execAsync = util.promisify(exec);



const CANVAS_SIZE = 1024
const COMP_SCALE1 = 8
const COMP_SCALE2 = 8
const MARGIN = 0.07 * CANVAS_SIZE



function horizontalDilate(image, kernelWidth) {
    const { width, height } = image.bitmap;
    const halfKernel = Math.floor(kernelWidth / 2);

    // 创建像素副本用于读取原始数据
    const srcBuffer = Buffer.from(image.bitmap.data);

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const idx = (y * width + x) * 4;

            // 如果当前像素已经是黑色，无需处理
            if (srcBuffer[idx] === 0) continue;

            // 检查水平方向[-halfKernel, +halfKernel]范围内是否存在黑色像素
            let hasBlack = false;
            for (let dx = -halfKernel; dx <= halfKernel; dx++) {
                const px = x + dx;
                if (px < 0 || px >= width) continue;

                const srcIdx = (y * width + px) * 4;
                if (srcBuffer[srcIdx] === 0) {
                    hasBlack = true;
                    break;
                }
            }

            // 如果范围内存在黑色，则将当前像素设为黑色
            if (hasBlack) {
                image.bitmap.data[idx] = 0;         // R
                image.bitmap.data[idx + 1] = 0;     // G
                image.bitmap.data[idx + 2] = 0;     // B
                // Alpha通道保持不变
            }
        }
    }
    return image;
}

function verticalDilate(image, kernelHeight) {
    return horizontalDilate(image.rotate(90), kernelHeight).rotate(-90);
}

function convertToBinary(image) {
    const threshold = 128; // 阈值范围 0-255
  
    image.scan(0, 0, image.bitmap.width, image.bitmap.height, (x, y, idx) => {
      const red = image.bitmap.data[idx];
      const green = image.bitmap.data[idx + 1];
      const blue = image.bitmap.data[idx + 2];
      const gray = (red + green + blue) / 3; // 计算灰度值
  
      // 根据阈值设置黑白
      const value = gray > threshold ? 255 : 0;
      image.bitmap.data[idx] = value;     // R
      image.bitmap.data[idx + 1] = value; // G
      image.bitmap.data[idx + 2] = value; // B
    });
  
    return image;
}

function convertToAlpha(image) {
    image.scan(0, 0, image.bitmap.width, image.bitmap.height, function(x, y, idx) {
        const red = this.bitmap.data[idx];
        const green = this.bitmap.data[idx + 1];
        const blue = this.bitmap.data[idx + 2];
        
        // 判断是否为白色（可调整阈值处理接近白色）
        const isWhite = red >= 255 && green >= 255 && blue >= 255;
        if (isWhite) {
          this.bitmap.data[idx + 3] = 0; // 设置Alpha为0
        }
    });
    return image;
}



if(fs.existsSync('./输出')){
    fs.rmSync('./输出', { recursive: true });
}
fs.mkdirSync('./输出')

console.log("读取文件……")

const workbook = XLSX.readFile('字表.xlsx');
const sheetName = workbook.SheetNames[0];
const worksheet = workbook.Sheets[sheetName];
const data = XLSX.utils.sheet_to_json(worksheet);

async function makeChar(name){
    if(fs.existsSync('./输出/'+name+'.bmp')){
        return await Jimp.read('./输出/'+name+'.bmp')
    }
    for(let i of fs.readdirSync('./字形')){
        if (i.split('.').slice(0, -1).join('.') == name){
            console.log("正在处理 "+name)
            var image = await Jimp.read('./字形/'+i);
            image = image.resize({w:CANVAS_SIZE, h:CANVAS_SIZE})
            image = convertToBinary(image);
            await image.write('./输出/'+name+'.bmp');
            return image;
        }
    }
    console.log("正在处理 "+name)
    var glyph1 = data.find(entry => entry['名称'] == name)["字形1"];
    var glyph2 = data.find(entry => entry['名称'] == name)["字形2"];
    var structure = data.find(entry => entry['名称'] == name)["结构"];
    var ratio = data.find(entry => entry['名称'] == name)["比例"];
    if(!glyph1){
        console.log(`警告：未找到字符 ${glyph1}`)
        glyph1 = (await Jimp.read("./blank.bmp")).resize({w:CANVAS_SIZE, h:CANVAS_SIZE});
    }else{
        glyph1 = await makeChar(glyph1);
    }
    if(!glyph2){
        console.log(`警告：未找到字符 ${glyph2}`)
        glyph2 = (await Jimp.read("./blank.bmp")).resize({w:CANVAS_SIZE, h:CANVAS_SIZE});
    }else{
        glyph2 = await makeChar(glyph2);
    }
    if(!["左右","上下"].includes(structure)){
        console.log(`警告：未知的结构 ${structure}`)
        structure = "左右";
    }
    if(!ratio){
        ratio = 1;
    }
    var image
    if(structure == "左右"){
        const totalK = ratio + 1
        const glyph1Width = Math.round(ratio / totalK * CANVAS_SIZE)
        // const glyph2Width = Math.round(CANVAS_SIZE - glyph1Width)
        const glyph2Width = Math.round(1 / totalK * CANVAS_SIZE)
        glyph1 = glyph1.resize({w:glyph1Width, h:CANVAS_SIZE});
        glyph2 = glyph2.resize({w:glyph2Width, h:CANVAS_SIZE});
        glyph1 = horizontalDilate(glyph1, CANVAS_SIZE/glyph1Width*COMP_SCALE1);
        glyph2 = horizontalDilate(glyph2, CANVAS_SIZE/glyph2Width*COMP_SCALE2);
        image = (await Jimp.read("./blank.bmp")).resize({w:CANVAS_SIZE, h:CANVAS_SIZE});
        // image.composite(glyph1, 0, 0);
        image.composite(glyph1, (1-ratio/totalK)*MARGIN, 0)
        // image.composite(glyph2, glyph1.bitmap.width, 0);
        glyph2 = convertToAlpha(glyph2)
        image.composite(glyph2, CANVAS_SIZE-glyph2Width-(1-1/totalK)*MARGIN, 0);
    }else if(structure == "上下"){
        const totalK = ratio + 1
        const glyph1Height = Math.round(ratio / totalK * CANVAS_SIZE)
        // const glyph2Height = Math.round(CANVAS_SIZE - glyph1Height)
        const glyph2Height = Math.round(1 / totalK * CANVAS_SIZE)
        glyph1 = glyph1.resize({w:CANVAS_SIZE, h:glyph1Height});
        glyph2 = glyph2.resize({w:CANVAS_SIZE, h:glyph2Height});
        glyph1 = verticalDilate(glyph1, CANVAS_SIZE/glyph1Height*COMP_SCALE1);
        glyph2 = verticalDilate(glyph2, CANVAS_SIZE/glyph2Height*COMP_SCALE2);
        image = (await Jimp.read("./blank.bmp")).resize({w:CANVAS_SIZE, h:CANVAS_SIZE});
        // image.composite(glyph1, 0, 0);
        image.composite(glyph1, 0, (1-ratio/totalK)*MARGIN)
        // image.composite(glyph2, 0, glyph1.bitmap.height);
        glyph2 = convertToAlpha(glyph2)
        image.composite(glyph2, 0, CANVAS_SIZE-glyph2Height-(1-1/totalK)*MARGIN);
    }
    await image.write('./输出/'+name+'.bmp');
    return image;
}

for (let entry of data){
    let name = entry['名称'];
    await makeChar(name);
}

for(let entry of data){
    let name = entry['名称'];
    let unicode = entry['Unicode'];
    if(!unicode){continue}
    console.log("正在编码 "+name)
    
    fs.copyFileSync('./输出/'+name+'.bmp', './输出/'+unicode+'.bmp');
    fs.rmSync('./输出/'+name+'.bmp', { recursive: true });
}

for(let entry of data){
    let name = entry['名称'];
    let unicode = entry['Unicode'];
    if(!unicode){continue}
    console.log("正在将 "+name+" 转换为矢量图")
    
    await execAsync(`mkbitmap ./输出/${unicode}.bmp -f 0 -t 1 -o ./输出/${unicode}.pbm`)
    await execAsync(`potrace ./输出/${unicode}.pbm -s -o ./输出/${unicode}.svg`)
}



console.log("开始打包字体……")

await new Promise(resolve=>{
    const fontStream = new SVGIcons2SVGFontStream({
        fontName: '我的字体',
    });
    
    fontStream
      .pipe(createWriteStream('./输出/我的字体.svg'))
      .on('finish', function () {
        var ttf = svg2ttf(fs.readFileSync('./输出/我的字体.svg', 'utf8'), {});
        fs.writeFileSync('./我的字体.ttf', new Buffer(ttf.buffer));
        console.log('### 字体已打包为 我的字体.ttf ###')
        resolve();
      })
      .on('error', function (err) {
        console.log(err);
      });
    
    for(let entry of data){
        let name = entry['名称'];
        let unicode = entry['Unicode'];
        if(!unicode){continue}
        console.log("正在编码 "+name)
        const glyph1 = createReadStream('./输出/'+unicode+'.svg');
        glyph1.metadata = {
            unicode: [String.fromCodePoint(parseInt(unicode, 16))],
            name: 'Unicode'+unicode,
        };
        fontStream.write(glyph1);
    }
    
    fontStream.end();
})

const html = `
<html>
    <head>
        <meta charset="utf-8">
        <title>字符表</title>
        <style>
            @font-face {
                font-family: '我的字体';
                src: url('./我的字体.ttf') format('truetype');
            }
        </style>
    </head>
    <body>
        <table>
            ${data.filter(entry=>entry['Unicode']).map(entry=>`<tr>
                <td style="font-size: 64px; font-family: '我的字体';">
                    ${String.fromCodePoint(parseInt(entry['Unicode'], 16))}
                </td>
                <td>
                    <div>U+${entry['Unicode']}</div>
                    <div>${entry['名称']}</div>
                </td>
            </tr>`)}
        </table>
    </body>
</html>
`
fs.writeFileSync('./字符表.html', html);

console.log("### 生成了 字符表.html，请查看 ###")

console.log("字体打包完毕，感谢使用")